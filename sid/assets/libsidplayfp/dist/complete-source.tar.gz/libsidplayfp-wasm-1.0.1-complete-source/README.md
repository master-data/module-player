# Complete corresponding source for libsidplayfp-wasm 1.0.1

This archive is the complete corresponding source, in the sense of section 3 of
the GNU General Public License version 2, for the WebAssembly binaries
distributed in libsidplayfp-wasm@1.0.1.

## Contents

| Directory | What it is |
| --- | --- |
| `libsidplayfp/` | https://github.com/libsidplayfp/libsidplayfp at `d7f7f0e78e09351ad53ff15a4cfb362c4f1c8339` (v3.0.2) |
| `libresidfp/` | https://github.com/libsidplayfp/libresidfp at `a5cd8f2486d627c40ea8c7c7a25827db73837002` (v1.1.2) |
| `libsidplayfp-wasm/` | The bindings, the scripts that modify upstream, and the build |

Both upstream trees are pristine, at the exact commits the binaries were built
from. The modifications this project applies are **not** baked into them: they
are applied at build time by `libsidplayfp-wasm/scripts/apply-thread-guards.py`
and `libsidplayfp-wasm/scripts/apply-sid-write-hook.py`, and are described in
`libsidplayfp-wasm/MODIFICATIONS.md`.

## Rebuilding

With Docker available:

```bash
cd libsidplayfp-wasm
bash scripts/build-all-wasm.sh
```

That fetches the same pinned commits, applies the modifications, and links both
engines. `docker/entrypoint.sh` is the authoritative build; it records the exact
compiler flags used.

## Licensing

libsidplayfp, libresidfp, and SIDLite are GPL-2.0-or-later. See
`libsidplayfp-wasm/THIRD-PARTY-NOTICES.md` for every component compiled into
the binaries and its licence, and `libsidplayfp-wasm/LICENSE` for the GPL text.
